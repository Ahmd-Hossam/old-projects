module Bourbon
  VERSION = "6.0.0"
end
